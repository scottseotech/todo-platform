"""todops - A minimal CLI for todo platform operations."""

__version__ = "0.1.0"
